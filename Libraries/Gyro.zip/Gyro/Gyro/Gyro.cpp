#include "Arduino.h"
#include <Wire.h>
#include "Gyro.h"

void Gyro::setupwire()
{

	//Wire
	Wire.begin();
	Wire.beginTransmission(0x68);						//0x68 is the adress for the MPU6050
	Wire.write(0x6B);									//calling register 'PWR_MGMT_1' 
	Wire.write(0);										//setting it to zero to activate to module
	Wire.endTransmission(true);							//end

	//setting gyro configuration to FS_SEL 1 500deg/sec and 65.5LSB/deg/sec (datasheet)

	Wire.beginTransmission(0x68);						//start communicating to MPU6050
	Wire.write(0x1B);									//0x1B is the Gyro_Config Register
	Wire.write(0x08);                                   //setting it to FS_SEL = 1(0x08) with 65.5 LSB					0x00=131LSB/deg/sec, 0x08=65.5LSBdeg/sec, 0x10=32.8LSBdeg/sec, 0x18=16.4LSBdeg/sec
	Wire.endTransmission();                             //end

	//setting accelerometer configuration to FS_SEL 1 0x08=8192LSB/g (datasheet)

	Wire.beginTransmission(0x68);						//start communicating to MPU6050
	Wire.write(0x1C);                                   //0x1C is the Acc_Config Register
	Wire.write(0x10);                                   //setting it to AFS_SEL to 0x10=4096LSB/g						0x00=16384LSB/g, 0x08=8192LSB/g, 0x10=4096LSB/g, 0x18=2048LSB/g
	Wire.endTransmission();								//end


	delay(100);

}

void Gyro::SetupWire(double TIME)
{

	//initialize time
	countTime = false;
	Time = TIME;
	setupwire();

	calibrateGyro();
}

void Gyro::SetupWire()
{
	countTime = true;
	setupwire();

	calibrateGyro();
}

void Gyro::calculateError()
{
	if (countTime)		//if 'time per iteration' is not set, count time between iterations
	{
		Time = micros() - prevTime;
		Time *= micro_to_sec;
		prevTime = micros();
	}

	readingMPU();
	calculateAngle();

}

void Gyro::setTarget(Vec3 Target)
{
	target = Target;
}

void Gyro::setCalibration(Vec3 Cal)
{
	cal = Cal;
}

void Gyro::readingMPU()
{
	//_______________________________________________________________________________________

	//Set Up Wire Communication

	Wire.beginTransmission(0x68);
	Wire.write(0x3B);
	Wire.endTransmission(false);
	Wire.requestFrom(0x68, 14, true);  // request a total of 14 registers

	//_______________________________________________________________________________________

	//Reading Data

	RawAcc.x = Wire.read() << 8 | Wire.read();  // 0x3B (ACCEL_XOUT_H) & 0x3C (ACCEL_XOUT_L)    
	RawAcc.y = Wire.read() << 8 | Wire.read();  // 0x3D (ACCEL_YOUT_H) & 0x3E (ACCEL_YOUT_L)
	RawAcc.z = Wire.read() << 8 | Wire.read();  // 0x3F (ACCEL_ZOUT_H) & 0x40 (ACCEL_ZOUT_L)

	tmp = Wire.read() << 8 | Wire.read();  // 0x41 (TEMP_OUT_H)   & 0x42 (TEMP_OUT_L)    // temperature(useless)

	RawGyro.x = Wire.read() << 8 | Wire.read();  // 0x43 (GYRO_XOUT_H) & 0x44 (GYRO_XOUT_L)    
	RawGyro.y = Wire.read() << 8 | Wire.read();  // 0x45 (GYRO_YOUT_H) & 0x46 (GYRO_YOUT_L)
	RawGyro.z = Wire.read() << 8 | Wire.read();  // 0x47 (GYRO_ZOUT_H) & 0x48 (GYRO_ZOUT_L)

	//_______________________________________________________________________________________


}

void Gyro::calculateAngle()
{
	
	//scaling values
	GyroScaled.x = ((RawGyro.x - GyroCal.x) / ScaleGyro);
	GyroScaled.y = ((RawGyro.y - GyroCal.y) / ScaleGyro);

	//Z Lowpass for Z axis
	if ((RawGyro.z - GyroCal.z) < limZ && (RawGyro.z - GyroCal.z) > (-limZ))
		GyroScaled.z = 0;
	else
		GyroScaled.z = ((RawGyro.z - GyroCal.z) / ScaleGyro);

	//_______________________________________________________________________________________  

	//integrating angular speed over time
	Gyro_angle.x += GyroScaled.x * Time;
	Gyro_angle.y += GyroScaled.y * Time;
	Gyro_angle.z += GyroScaled.z * Time;


	//Involving opposite component multiplied by sin of z
	Gyro_angle.x += Gyro_angle.y * sin(GyroScaled.z * Time * deg_to_rad);
	Gyro_angle.y -= Gyro_angle.x * sin(GyroScaled.z * Time * deg_to_rad);

	//_______________________________________________________________________________________

	//Calculating Acceleration Angle and total Acc vector
	Acc_totalVec = sqrt(pow(RawAcc.x, 2) + pow(RawAcc.y, 2) + pow(RawAcc.z, 2) ) / ScaleAcc;

	Acc_angle.x =  atan(RawAcc.y / sqrt(pow(RawAcc.x, 2) + pow(RawAcc.z*0.85, 2))) * rad_to_deg;
	Acc_angle.y = -atan(RawAcc.x / sqrt(pow(RawAcc.y, 2) + pow(RawAcc.z*0.85, 2))) * rad_to_deg;


	//_______________________________________________________________________________________

	//Set  acc_angle absolut on first Iteration or calculating Angle based on 99% Gyro and 1% Acceleration Angle

	if (GyroSet)
	{

		Gyro_angle.x = Acc_angle.x;
		Gyro_angle.y = Acc_angle.y;
		Gyro_angle.z = 0;

		GyroSet = false;

	}

	//checking if Acceleration-Angle is valid
	if(RawAcc.z > -100 && Acc_totalVec > 0.1)
	{ 
			Gyro_angle.x = 0.99 * Gyro_angle.x + Acc_angle.x * 0.01;
			Gyro_angle.y = 0.99 * Gyro_angle.y + Acc_angle.y * 0.01;
	}


	//_______________________________________________________________________________________

	//Calculating Error, based on Calibration and Target Angle
	error.x = Gyro_angle.x - target.x - cal.x;
	error.y = Gyro_angle.y - target.y - cal.y;
	error.z = Gyro_angle.z - target.z - cal.z;
	
	//_______________________________________________________________________________________

}

void Gyro::calibrateGyro()
{
	double x = 0;
	double y = 0;
	double z = 0;

	int n = 1500;

	for (int i = 0; i < n; i++)
	{
		readingMPU();

		x += RawGyro.x;
		y += RawGyro.y;
		z += RawGyro.z;
	}
	//Serial.println("Gyro calibrated");

	delay(100);

	GyroCal.x = x / n;
	GyroCal.y = y / n;
	GyroCal.z = z / n;

}

Vec3 Gyro::calibrate(int n)
{

	float tempX = 0;
	float tempY = 0;
	Vec3 temp;

	setTarget({ 0,0,0 });
	setCalibration({ 0,0,0 });
	calibrateGyro();

	for (int i = 0; i < n; i++)
	{
		calculateError();

		tempX += error.x;
		tempY += error.y;

		//tone(BUZZER, i + 1000, 5);
	}

	temp.x = tempX / n;
	temp.y = tempY / n;


	return temp;
}

void Gyro::zeroYaw(bool lt)
{
	if (lt)
		Gyro_angle.z = 0;

}

